#!/usr/bin/env  bash
function_lib_dir=/envauto/function_lib/function_lib.sh

if [ -e ${funtion_lib_dir} ];then
        source ${function_lib_dir}
else
        echo "function library not exsit"
        exit 1
fi

#install devel depen
#devel_depen

#download python src package 
#wget_python_package

#install python scr package
#python_src_install

#install django
#install_django

#install uwsgi
#install_uwsgi

#wget nginx src package 
wget_nginx_package 

#install nginx src package
install_nginx_package
