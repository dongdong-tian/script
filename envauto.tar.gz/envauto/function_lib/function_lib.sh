#!/bin/bash
###########################################
#decription: the scripte help our install #
#	     python、django、wusgi、nginx #
#	     application.                 #
#Author:Dongdong Tian                     #
#                                         #
#                                         #
###########################################

#set global variable
function_dir=/envauto/function_lib/function_lib.sh
package_dir=/envauto/package

#set python variables
py_package_dir=${package_dir}/python
py_package_url="https://www.python.org/ftp/python/3.6.6/Python-3.6.6.tgz"
python_install_dir=/usr/local/python3-6-6

#set nginx variables
nginx_package_dir=${package_dir}/nginx
nginx_install_dir=/usr/local/nginx
nginx_package_url="http://nginx.org/download/nginx-1.13.7.tar.gz"




function status_judg {
if [ $?  -eq 0 ];then
	echo "$1 Success..."
else
	echo "$1 Failed,pleases cheek..." && exit 1
fi
}

function devel_depen {
yum group list  &>/dev/null 
status_judg 'group list'

#############################################
echo "#####install Development tools pleases wait...#####"
yum -y groupinstall "Development tools" &>/dev/null
status_judg 'install Development tools'

#############################################
echo "#####search  Devel package pleases wait...#####"
yum search openssl-devel bzip2-devel expat-devel gdbm-devel readline-devel sqlite-devel &>/dev/null
status_judg 'search devel package'

#############################################
echo "#####install Devel package pleases wait...#####"
yum install -y openssl-devel bzip2-devel expat-devel gdbm-devel readline-devel sqlite-devel &>/dev/null
status_judg 'install devel package'
}


function wget_python_package {
echo "#####wget python package pleases wait...#####"
[ ! -e ${package_dir} ]&& mkdir -p ${package_dir}
[ -e ${py_package_dir} ] && rm -rf ${py_package_dir}
[ ! -e ${py_package_dir} ] && mkdir -p ${py_package_dir}

cd  ${py_package_dir}
py_package_name=`echo ${py_package_url}|awk -F '/' '{print $NF}'`
wget ${py_package_url} &>/dev/null 
status_judg "wget ${py_package_name}"

}

function python_src_install {
echo "#####install python package pleases wait...#####"
cd ${py_package_dir}

tar -xf ${py_package_name} &>/dev/null
status_judg "tar -xf ${py_package_name}"

rm -rf  ${py_package_name}
status_judg "delete ${py_package_name}"

py_tar_dir=`ls`
status_judg "get python uncompress directory name "

#############################################
echo "#####make  python src package pleases wait...#####"
cd ${py_tar_dir}
./configure --prefix=${python_install_dir} &>/dev/null
status_judg './configure python'

make &>/dev/null
status_judg 'make python'

make install  &>/dev/null
status_judg 'make install python'

ln -s ${python_install_dir}/bin/python3.6 /usr/bin/python3 &>/dev/null
ln -s ${python_install_dir}/bin/pip3.6 /usr/bin/pip3 &>/dev/null

}

function install_django {
echo "#####install django pleases wait...#####"
pip3 install django &>/dev/null
status_judg 'django install '
ln -s ${python_install_dir}/bin/django-admin.py
}

function install_uwsgi {
echo "#####install uwsgi pleases wait...#####"
pip3 install uwsgi &>/dev/null
status_judg 'uwsgi install '
ln -s  ${python_install_dir}/bin/uwsgi  /usr/bin/uwsgi
}

#function create_project {
#cd ${project_dir}
#django-admin.py startproject ${site_name}
#python3 manage.py startapp  ${app_name}
#sed -i "/staticfiles/a "\'${app_name}\',""   ${project_dir}/${site_name}/settings.py
#sed -i "/ALLOWED/ s/\[\]/\[\*\]/g"    ${project_dir}/${site_name}/settings.py
#sed -i  "/DIRS/ s/\[\]/\[os\.path\.join\(BASE_DIR\, \'templates\'\)\]/g" ${project_dir}/${site_name}/settings.py
#
#echo  "STATICFILES_DIRS = ("  >> ${project_dir}/${site_name}/settings.py
#echo "    os.path.join(BASE_DIR,'static')," >> ${project_dir}/${site_name}/settings.py
#echo " )"  >> ${project_dir}/${site_name}/settings.py
#
#}

function wget_nginx_package {
echo "#####wget nginx package pleases wait...#####"
[ ! -e ${package_dir} ]&& mkdir -p ${package_dir}
[ -e ${nginx_package_dir} ] && rm -rf  ${nginx_package_dir}
[ ! -e ${nginx_package_dir} ] && mkdir -p ${nginx_package_dir}

nginx_package_name=`echo ${nginx_package_url}|awk -F '/' '{print $NF}'`
cd  ${nginx_package_dir}
wget  ${nginx_package_url}  &>/dev/null
status_judg "wget ${nginx_package_name}"

}

function  install_nginx_package {
echo "#####install nginx package pleases wait...#####"

cd ${nginx_package_dir}
tar -xf ${nginx_package_name} &>/dev/null
status_judg "tar -xf ${nginx_package_name}"

rm -rf  ${nginx_package_name}
status_judg "delete ${nginx_package_name}"

nginx_tar_dir=`ls`
status_judg "get nginx uncompress directory name "

echo "make nginx src package pleases wait..."
cd ${nginx_tar_dir}
./configure --prefix=${nginx_install_dir} &>/dev/null
status_judg './configure nginx'

make &>/dev/null
status_judg 'make nginx'

make install  &>/dev/null
status_judg 'make install nginx'

ln -s ${nginx_install_dir}/sbin/nginx  /usr/bin/nginx
status_judg 'ln -s  nginx command  to /usr/bin'

#nginx 
#status_judg 'nginx start'

}
